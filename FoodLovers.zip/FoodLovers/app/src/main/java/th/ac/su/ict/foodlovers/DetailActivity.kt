package th.ac.su.ict.foodlovers

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_detail.*

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val title = intent.getStringExtra("title")
        val caption = intent.getStringExtra("caption")
        val imageFile = intent.getStringExtra("imageFile")
        val description = intent.getStringExtra("description")
        val star = intent.getIntExtra("star",0)

        tvTitle.setText(title)
        tvCaption.setText(caption)
        tvDescription.setText(description)
        tvShop.rating = star.toFloat()



        val res = resources
        val drawableId:Int =
            res.getIdentifier(imageFile,"drawable",packageName)

        imgView.setImageResource(drawableId)


    }
}